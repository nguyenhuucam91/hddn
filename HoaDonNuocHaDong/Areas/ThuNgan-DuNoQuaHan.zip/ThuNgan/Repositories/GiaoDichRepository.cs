﻿using System;
using System.Linq;
using HDNHD.Core.Repositories;
using HDNHD.Models.DataContexts;
using HoaDonNuocHaDong.Areas.ThuNgan.Models;
using HoaDonNuocHaDong.Areas.ThuNgan.Repositories.Interfaces;

namespace HoaDonNuocHaDong.Areas.ThuNgan.Repositories
{
    public class GiaoDichRepository : LinqRepository<HDNHD.Models.DataContexts.GiaoDich>, IGiaoDichRepository
    {
        private HDNHDDataContext dc;

        public GiaoDichRepository(HDNHDDataContext context) : base(context) {
            dc = context;
        }

        public IQueryable<GiaoDichModel> GetAllByKHID(int khachHangID)
        {
            return from gd in dc.GiaoDiches
                   join stntt in dc.SoTienNopTheoThangs on gd.TienNopTheoThangID equals stntt.ID
                   join hd in dc.Hoadonnuocs on stntt.HoaDonNuocID equals hd.HoadonnuocID
                   where hd.KhachhangID == khachHangID
                   orderby gd.GiaoDichID descending

                   select new GiaoDichModel()
                   {
                       GiaoDich = gd,
                       HoaDon = hd,
                       SoTienNopTheoThang = stntt
                   };
        }
    }
}