﻿using HDNHD.Core.Repositories.Interfaces;
using HoaDonNuocHaDong.Areas.ThuNgan.Models;
using System.Linq;

namespace HoaDonNuocHaDong.Areas.ThuNgan.Repositories.Interfaces
{
    public interface IGiaoDichRepository : IRepository<HDNHD.Models.DataContexts.GiaoDich>
    {
        IQueryable<GiaoDichModel> GetAllByKHID(int khachHangID);
    }
}
