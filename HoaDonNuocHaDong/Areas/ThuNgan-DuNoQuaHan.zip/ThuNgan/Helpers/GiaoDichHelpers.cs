﻿using HoaDonNuocHaDong.Areas.ThuNgan.Models;
using HoaDonNuocHaDong.Areas.ThuNgan.Repositories;
using HoaDonNuocHaDong.Areas.ThuNgan.Repositories.Interfaces;
using HoaDonNuocHaDong.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HoaDonNuocHaDong.Areas.ThuNgan.Helpers
{
    public class GiaoDichHelpers
    {
        /// <summary>
        /// Khách hàng thanh toán hóa đơn hoặc nộp vào tài khoản
        /// ngayThu không đúng > ngày hiện tại
        /// </summary>
        /// <requires>
        /// model != null /\ model.KhachHang != null /\ model.SoTienNopTheoThang != null /\ soTien > 0
        /// </requires>
        /// <effects>
        /// create new GiaoDich & insert
        /// update model
        ///     SoTienDaThu += soTien
        /// 
        /// while soTien > 0 && model != null
        ///     DuNo -= soTien
        ///     if soTien > DuNoQuaHan && DuNoQuaHan > 0
        ///         DuNo -= soTien - DuNoQuaHan
        ///         soTien = DuNoQuaHan
        ///     if DuNo == 0
        ///         update TrangThaiThu = true
        ///         NgayThu = <tt>ngayThu</tt>
        ///         
        ///     model = prev unpaid HoaDonModel (latest to oldest)
        /// </effects>
        public static bool ThemGiaoDich(HoaDonModel model, int soTien, DateTime? ngayThu = null, HDNHDUnitOfWork uow = null)
        {
            //
            if (ngayThu == null) ngayThu = DateTime.Now;
            if (uow == null) uow = new HDNHDUnitOfWork();
            IGiaoDichRepository giaoDichRepository = uow.Repository<GiaoDichRepository>();
            IHoaDonRepository hoaDonRepository = uow.Repository<HoaDonRepository>();

            uow.BeginTransaction();
            try
            {
                // add new GiaoDich
                var giaoDich = new HDNHD.Models.DataContexts.GiaoDich()
                {
                    TienNopTheoThangID = model.SoTienNopTheoThang.ID,
                    SoTien = soTien,
                    NgayGiaoDich = ngayThu
                };
                giaoDichRepository.Insert(giaoDich);

                // update model
                // TODO: Thêm vào số tiền đã thu của tháng hiện tại chứ không phải 
                model.SoTienNopTheoThang.SoTienDaThu += soTien;

                // pay for DuNoQuaHan
                while (soTien > 0 && model != null)
                {
                    model.SoTienNopTheoThang.DuNo -= soTien;
                    if (model.SoTienNopTheoThang.DuNoQuaHan > 0 && soTien > model.SoTienNopTheoThang.DuNoQuaHan)
                    {
                        model.SoTienNopTheoThang.DuNo -= soTien - model.SoTienNopTheoThang.DuNoQuaHan;
                        soTien = model.SoTienNopTheoThang.DuNoQuaHan;
                    }
                    if (model.SoTienNopTheoThang.DuNo == 0)
                    {
                        model.HoaDon.Trangthaithu = true;
                        model.HoaDon.NgayNopTien = ngayThu;
                    }
                    // previous unpaid HoaDonModel of this customer
                    model = hoaDonRepository.GetPrevUnPaidHoaDonModel(model);
                }

                uow.SubmitChanges();
                uow.Commit();
                return true;
            } catch (Exception)
            {
                uow.RollBack();
            }
            return false;
        }

        /// <summary>
        /// Hủy giao dịch với id xác định
        /// </summary>
        /// <requires>
        /// lastGiaoDich != null /\ lastGiaoDich.GiaoDich.SoTien != null
        /// </requires>
        /// <effects>
        /// soTien = lastGiaoDich.SoTien
        /// delete GiaoDich
        /// 
        /// update model
        ///     SoTienDaThu -= soTien
        ///     
        /// if soTien lt= DuCo
        ///     DuCo -= soTien
        ///     soTien = 0
        /// else
        ///     soTien -= DuCo
        /// 
        /// while soTien > 0 && model != null  
        ///     DuNo += soTien
        ///     if soTien > DuNoQuaHan && DuNoQuaHan > 0
        ///         DuNo += soTien - DuNoQuaHan
        ///         soTien = DuNoQuaHan
        ///     if TrangThaiThu == true
        ///         update TrangThaiThu = false
        ///         ngayThu = today (ngày hủy giao dịch)
        ///     model = next paid HoaDonModel (latest to oldest)
        /// </effects>
        public static bool HuyGiaoDich(GiaoDichModel giaoDichModel, HDNHDUnitOfWork uow = null)
        {
            IGiaoDichRepository giaoDichRepository = uow.Repository<GiaoDichRepository>();
            IHoaDonRepository hoaDonRepository = uow.Repository<HoaDonRepository>();
            
            uow.BeginTransaction();
            try
            {
                var soTien = giaoDichModel.GiaoDich.SoTien.Value;
                giaoDichRepository.Delete(giaoDichModel.GiaoDich);

                var model = hoaDonRepository.GetHoaDonModelByID(giaoDichModel.HoaDon.HoadonnuocID);
                // update model
                model.SoTienNopTheoThang.SoTienDaThu -= soTien;

                // trừ dư có
                if (soTien <= model.SoTienNopTheoThang.DuCo)
                {
                    model.SoTienNopTheoThang.DuCo -= soTien;
                    soTien = 0;
                }
                else
                    soTien -= model.SoTienNopTheoThang.DuCo;

                while (soTien > 0 && model != null)
                {
                    model.SoTienNopTheoThang.DuNo += soTien;
                    if (model.SoTienNopTheoThang.DuNoQuaHan > 0 && soTien > model.SoTienNopTheoThang.DuNoQuaHan)
                    {
                        model.SoTienNopTheoThang.DuNo += soTien - model.SoTienNopTheoThang.DuNoQuaHan;
                        soTien = model.SoTienNopTheoThang.DuNoQuaHan;
                    }

                    if (model.HoaDon.Trangthaithu == true)
                    {
                        model.HoaDon.Trangthaithu = false;
                        model.HoaDon.NgayNopTien = DateTime.Now; // ngày hủy giao dịch
                    }
                    // previous unpaid HoaDonModel of this customer
                    model = hoaDonRepository.GetPrevPaidHoaDonModel(model);
                }

                uow.SubmitChanges();
                uow.Commit();
                return true;
            } catch(Exception e)
            {
                uow.RollBack();
            }

            return false;
        }
    }
}